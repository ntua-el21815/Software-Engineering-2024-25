# CLI client

Ενδεικτικά περιεχόμενα:

- Command line interface (CLI).
- CLI functional tests.
- CLI unit tests.
